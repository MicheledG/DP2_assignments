@javax.xml.bind.annotation.XmlSchema(namespace = "http://it.polito.dp2.NFFG.sol3.service.jaxb")
package it.polito.dp2.NFFG.sol3.client2.nffgservice;
